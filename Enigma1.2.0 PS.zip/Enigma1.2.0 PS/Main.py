from tkinter import *
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
from ttkbootstrap.style import Style
from Fucion import descriptografar, criptografar

def descript_to_cript():
    Painel_Descript.pack_forget()
    Painel_Cript.pack(fill='both', expand=True)
    criptografado_Entry.delete(0, END)
    resultados_Textcase.delete("1.0", "end")

def cript_to_descript():
    Painel_Cript.pack_forget()
    Painel_Descript.pack(fill='both', expand=True)
    Descriptografado_Entry.delete(0, END)
    resultados_Textcase2.delete("1.0", "end")

def handle_descriptografar():
    codigo = criptografado_Entry.get().lower()
    codigodescriptografado = descriptografar(codigo)
    resultados_Textcase.insert(END, codigodescriptografado + "\n")
    criptografado_Entry.delete(0, END)

def handle_criptografar():
    codigo = Descriptografado_Entry.get().lower()
    codigocritografado = criptografar(codigo)
    resultados_Textcase2.insert(END, codigocritografado + "\n")
    Descriptografado_Entry.delete(0, END)

janela = ttk.Window()
janela.title("Basigma")
janela.geometry("1000x780+550+125")
janela.resizable(True, True)
janela.iconbitmap(r'Enigma1.2.0 PS\Icon.ico')
style = Style(theme="solar")

main_frame = ttk.Frame(janela)
main_frame.pack(padx=10, pady=10, fill='both', expand=False)

Painel_Descript = ttk.Frame(main_frame)
Painel_Descript.pack(fill='both', expand=False)
ttk.Label(Painel_Descript, text="Área de Descriptografia", font=('', 18)).pack(padx=10, pady=10, fill='y')

criptografado = ttk.Frame(Painel_Descript)
criptografado.pack(padx=5, pady=5, fill='x')
criptografado_Label = ttk.Label(criptografado, text="Digite o Texto Criptografado:", font=('', 15)).pack(side=LEFT, padx=5, pady=5, fill='x')
criptografado_Entry = ttk.Entry(criptografado, font=("arial", 12))
criptografado_Entry.pack(padx=5, side=LEFT, fill="x", expand=True)
Descriptografia_button = ttk.Button(criptografado, text="Descriptografar", command=handle_descriptografar, bootstyle=OUTLINE).pack(side=LEFT, padx=5)

resultados_janela = ttk.Frame(Painel_Descript)
resultados_janela.pack(padx=10, fill='x')
resultados_Label = ttk.Label(resultados_janela, text="Texto Descriptografado:", font=("arial", 15)).pack()
resultados_Textcase = ttk.Text(resultados_janela, font=("arial", 12))
resultados_Textcase.pack(pady=10, fill='x')
To_cript_Label = ttk.Label(resultados_janela, text="Gostaria de Criptografar uma Mensagem?", font=("arial", 10)).pack(side=LEFT, fill='x')
To_cript_button = ttk.Button(resultados_janela, text="Clique Aqui", command=descript_to_cript, bootstyle=LINK).pack(side=LEFT, fill="x")

Painel_Cript = ttk.Frame(main_frame)
Painel_Cript.pack(fill='both', expand=True)
ttk.Label(Painel_Cript, text="Área de Criptografia", font=('', 18)).pack(padx=10, pady=10, fill='y')

Descriptografado = ttk.Frame(Painel_Cript)
Descriptografado.pack(padx=5, pady=5, fill='x')
Descriptografado_Label = ttk.Label(Descriptografado, text="Digite o Texto Descriptografado:", font=('', 15)).pack(side=LEFT, padx=5, pady=5, fill='x')
Descriptografado_Entry = ttk.Entry(Descriptografado, font=("arial", 12))
Descriptografado_Entry.pack(padx=5, side=LEFT, fill="x", expand=True)
Criptografia_button = ttk.Button(Descriptografado, text="Criptografar", command=handle_criptografar, bootstyle=OUTLINE).pack(side=LEFT, padx=5)

resultados_janela2 = ttk.Frame(Painel_Cript)
resultados_janela2.pack(padx=10, fill='x')
resultados_Label2 = ttk.Label(resultados_janela2, text="Texto Criptografado:", font=("arial", 15)).pack()
resultados_Textcase2 = ttk.Text(resultados_janela2, font=("arial", 12))
resultados_Textcase2.pack(pady=10, fill='x')
To_Descript_Label2 = ttk.Label(resultados_janela2, text="Gostaria de Descriptografar uma Mensagem?", font=("arial", 10)).pack(side=LEFT, fill='x')
To_Descript_button2 = ttk.Button(resultados_janela2, text="Clique Aqui", command=cript_to_descript, bootstyle=LINK).pack(side=LEFT, fill="x")

Painel_Cript.pack_forget()

janela.mainloop()
