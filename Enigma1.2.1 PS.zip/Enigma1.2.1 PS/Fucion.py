from data import Dicionario_Descript,Dicionario_Cript
def descriptografar(codigo):
    
    codigodecodificado = ""
    i = 0
    while i < len(codigo):
        if i + 1 < len(codigo) and codigo[i:i+2] in Dicionario_Descript:
            codigodecodificado += Dicionario_Descript[codigo[i:i+2]]
            i += 2
        elif codigo[i] in Dicionario_Descript:
            codigodecodificado += Dicionario_Descript[codigo[i]]
            i += 1
        else:
            codigodecodificado += codigo[i]
            i += 1

    return codigodecodificado

def criptografar(codigo):

    codigodecodificado = ""
    i = 0
    while i < len(codigo):
        if i + 1 < len(codigo) and codigo[i:i+2] in Dicionario_Cript:
            codigodecodificado += Dicionario_Cript[codigo[i:i+2]]
            i += 2
        elif codigo[i] in Dicionario_Cript:
            codigodecodificado += Dicionario_Cript[codigo[i]]
            i += 1
        else:
            codigodecodificado += codigo[i]
            i += 1

    return codigodecodificado